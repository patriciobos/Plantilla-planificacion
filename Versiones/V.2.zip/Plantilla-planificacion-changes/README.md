# Plantilla-planificacion
Plan de proyecto para trabajos finales de posgrado en Internet de las Cosas
